---
title: Test
permalink: /test/
layout: test
---

hello, this is content!
