# Erkin's Blog
