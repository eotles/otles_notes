---
title: "Wisconsin Engineer: Optimizing the ER"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
---

April Soler, Sam Schmitt, and I discussed our win at the [Flexsim-SHS Emergency Department Modeling Competition]({{ site.baseurl }}{% link _posts/2015-03-31-SHS-FlexSim.md %}) with Kelsey Murphy for an [article in the Wisconsin Engineer magazine](https://search.library.wisc.edu/digital/AFJAZLALE6WG558O/pages/AFSPWRZMI6BFAZ9B).

<img src="{{ site.url }}{{ site.baseurl }}/assets/post_assets/2015-Wisconsin-Engineer/optimizing_the_er.jpg" alt="Optimizing the ER, article from the Wisconsins Engineer." >
