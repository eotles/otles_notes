---
title: "UMich IOE Promo Video"
categories:
  - Blog
tags:
  - Blog
  - industrial engineering
  - operations research
---

Was featured in the University of Michigan Department of Industrial and Operations Engineering promotional video. 

> University of Michigan Industrial and Operations Engineering graduates are in high demand and use mathematics, and data analytics to launch their careers and create solutions across the globe in business, consulting, energy, finance, healthcare, manufacturing, robotics, aerospace, transportation, supply chain and more.

<iframe width="560" height="315" src="https://www.youtube.com/embed/UD1BsutVhcE?start=131" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
