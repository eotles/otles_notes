---
title: "AAFP's Innovation Fellow Studies Tech, Digital Scribes"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
---

Discussed my work studying digital scribes with David Mitchell. [Read the interview](https://www.aafp.org/news/practice-professional-issues/20190320itfellow.html).
