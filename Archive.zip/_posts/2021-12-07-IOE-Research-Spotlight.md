---
title: "IOE Research Spotlight"
categories:
  - Blog
  - Talk
tags:
  - medicine
  - healthcare
  - machine learning
  - artificial intelligence
  - operations research
  - industrial engineering
  - health system engineering
---

Shared an overview of my research during the 2021 University of Michigan Department of Industrial and Operations Engineering recruiting weekend.

<iframe width="560" height="315" src="https://www.youtube.com/embed/Xl3oLFACiJU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
