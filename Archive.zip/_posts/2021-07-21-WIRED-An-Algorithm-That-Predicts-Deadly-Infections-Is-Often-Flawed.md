---
title: "WIRED: An Algorithm That Predicts Deadly Infections Is Often Flawed"
categories:
  - Blog
  - Research
tags:
  - Blog
  - Press
  - sepsis
  - deterioration index
  - Epic
  - early warning system
  - medicine
  - healthcare
  - artificial intelligence
  - machine learning
  - WIRED
---

Tom Simonite of WIRED covered our [JAMA IM Epic Sepsis Model evaluation paper]({{ site.baseurl }}{% link _posts/2021-07-21-External-Validation-of-a-Widely-Implemented-Proprietary-Sepsis-Prediction-Model-in-Hospitalized-Patients.md %}). Check out the [article](https://www.wired.com/story/algorithm-predicts-deadly-infections-often-flawed/).
