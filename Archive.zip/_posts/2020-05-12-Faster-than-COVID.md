---
title: "Faster than COVID: a computer model that predicts the disease’s next move"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
  - covid
  - artificial intelligence
  - machine learning
  - early warning system
---

Michigan Engineering News covered our work on the M-CURES COVID deterioration model that I helped to develop and led the implementation of. Read the article [here](https://news.engin.umich.edu/2020/05/faster-than-covid-a-computer-model-that-predicts-the-diseases-next-move/).
