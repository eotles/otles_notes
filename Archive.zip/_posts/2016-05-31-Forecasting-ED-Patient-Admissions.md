---
title: "Forecasting Emergency Department Patient Admissions Utilizing Machine Learning"
categories:
  - Blog
  - Research
tags:
  - Blog
  - Research
  - emergency medicine
  - medicine
  - healthcare
  - health system engineering
  - artificial intelligence
  - machine learning
  - operations research
---

Academic Emergency Medicine abstract. Work done in conjunction with Drs. Brian Patterson, Jillian Gorski, and Laura Albert.


<iframe src="{{ site.url }}{{ site.baseurl }}/assets/papers/forecasting_ED_patient_admissions.pdf" 
    style="aspect-ratio: 8.5 / 11;"
    width="100%" 
>
</iframe>

[Download paper.]({{ site.url }}{{ site.baseurl }}/assets/papers/forecasting_ED_patient_admissions.pdf)
