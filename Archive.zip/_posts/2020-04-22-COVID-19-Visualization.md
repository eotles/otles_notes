---
title: "COVID-19 Analysis"
categories:
  - Blog
  - Project
tags:
  - data science
  - covid
---


Quick exploration of case spread and mortality rates of the novel coronavirus.

<iframe seamless frameborder="0" src="https://public.tableau.com/views/COVID-19_15841289274910/Story1?:embed=yes&:display_count=yes&:showVizHome=no" width = '850' height = '600' scrolling='yes' ></iframe>

Tableau embed code courtesy of [San Wang](https://san-wang.github.io/blog/Embed-Tableau-dashboard-into-github-page-post/).
