---
title: "The Verge: A hospital algorithm designed to predict a deadly condition misses most cases"
categories:
  - Blog
  - Research
tags:
  - Blog
  - Press
  - sepsis
  - deterioration index
  - Epic
  - early warning system
  - medicine
  - healthcare
  - artificial intelligence
  - machine learning
  - The Verge
---

Nicole Wetsman of The Verge covered our [JAMA IM Epic Sepsis Model evaluation paper]({{ site.baseurl }}{% link _posts/2021-07-21-External-Validation-of-a-Widely-Implemented-Proprietary-Sepsis-Prediction-Model-in-Hospitalized-Patients.md %}). Check out the [article](https://www.theverge.com/2021/6/22/22545044/algorithm-hospital-sepsis-epic-prediction).
