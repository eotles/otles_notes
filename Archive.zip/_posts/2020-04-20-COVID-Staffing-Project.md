---
title: "COVID Staffing Project: Three Medical Students’ Contributions"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
---

 Kenneth Abbott, Alexandra Highet and I catalogued our contributions to the COVID Staffing project in a [Dose of Reality Blog Post](https://umdoseofreality.org/9420/the-covid-staffing-project-three-medical-students-contributions).
