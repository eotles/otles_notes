---
title: "Forbes: Trust The AI? You Decide"
categories:
  - Blog
  - Research
tags:
  - Blog
  - Press
  - sepsis
  - deterioration index
  - Epic
  - early warning system
  - medicine
  - healthcare
  - artificial intelligence
  - machine learning
  - Forbes
---

Arun Shashtri of Forbes covered our [JAMA IM Epic Sepsis Model evaluation paper]({{ site.baseurl }}{% link _posts/2021-07-21-External-Validation-of-a-Widely-Implemented-Proprietary-Sepsis-Prediction-Model-in-Hospitalized-Patients.md %}). Check out the [article](https://www.forbes.com/sites/arunshastri/2021/11/02/trust-the-ai-you-decide/).
