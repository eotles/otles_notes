---
title: "UMich Precision Health Symposium: Prediction & Prevention - Powering Precision Health"
categories:
  - Blog
  - Talk
tags:
  - medicine
  - healthcare
  - precision health
  - machine learning
  - artificial intelligence
  - operations research
---


Virtual panel discussion on precison health. A video segment from the 2020 University of Michigan Precision Health Virtual Symposium.

<iframe width="560" height="315" src="https://www.youtube.com/embed/GRajhsQXT2Q?start=1282" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
