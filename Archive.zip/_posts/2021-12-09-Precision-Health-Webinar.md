---
title: "Precision Health Webinar: What Clinicians Need to Know when Using AI"
categories:
  - Blog
  - Talk
tags:
  - medicine
  - machine learning
  - artificial intelligence
---


Panel discussion on what is important for clinicians to know and how confident they can be when using these AI tools. Conversation with Drs. Rada Mihalcea, Max Spadafore, and Cornelius James.

<iframe width="560" height="315" src="https://www.youtube.com/embed/aWYNj6eZWls" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
