---
title: "Helping people get back to work using deep learning in the occupational health system"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
  - occupational health
  - return to work
  - medicine
  - healthcare
  - artificial intelligence
  - machine learning
---

Discussed our recent [JAMIA paper on predicting return to work]({{ site.baseurl }}{% link _posts/2022-08-29-Dynamic-prediction-of-work-status-for-workers-with-occupational-injuries.md %}) with Jessalyn Tamez. Check out the news brief [here](https://ioe.engin.umich.edu/2022/08/30/helping-people-get-back-to-work-using-deep-learning-in-the-occupational-health-system/).
