---
title: "Send Me Specials Website"
categories:
  - Blog
  - Project
tags:
  - software development
---


We hacked together a fully integrated custom text message gateway, app, and website.
