---
title: "UMich Precision Health Onboarding Session: Precision Health De-Identified RDW"
categories:
  - Blog
  - Talk
tags:
  - medicine
  - healthcare
  - precision health
  - machine learning
  - artificial intelligence
  - operations research
---


Precision Health Data Analytics & IT workgroup held an onboarding session for Engineering students who could use Precision Health tools and resources for their classes and research. I provided a technical demonstration on how to find and query the database through the sql server.

<iframe width="560" height="315" src="https://www.youtube.com/embed/P_d75tvs8pY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
