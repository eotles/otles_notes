---
title: "I-PrACTISE Colloquium Primary Care & Predictive Analytics"
categories:
  - Blog
  - Talk
tags:
  - primary care
  - medicine
  - healthcare
  - machine learning
  - artificial intelligence
  - operations research
  - industrial engineering
---


Talk on the intersection of primary care and predictive analytics (machine learning & artificial intelligence).

<iframe width="560" height="315" src="https://www.youtube.com/embed/ipC5jYpyv6Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
