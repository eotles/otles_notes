---
title: "STAT News: How medical schools are missing the mark on artificial intelligence"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
  - artificial intelligence
  - machine learning
  - medical education
  - medical school
  - STAT News
---

Discussed my recent [perspective paper on incorporating AI into medical education](https://www.sciencedirect.com/science/article/pii/S2666379122003834) with Dr. James Woolliscroft and Katie Palmer of STAT News. Check out the full discussion [here](https://www.statnews.com/2023/01/12/medical-school-artificial-intelligence-health-curriculum/).
