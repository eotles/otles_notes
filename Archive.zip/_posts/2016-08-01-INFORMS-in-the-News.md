---
title: "Quoted in INFORMS in the News"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
---

Was quoted in [INFORMS in the News](https://pubsonline.informs.org/do/10.1287/orms.2016.04.03/full) regarding setting up the University of Wisconsin student INFORMS chapter.
