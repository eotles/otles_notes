---
title: "UMich MSTP Promo Video"
categories:
  - Blog
  - Press
tags:
  - Blog
  - Press
  - medicine
  - MSTP
---

Was featured in the University of Michigan Medical Scientist Training Program recruiting video. 
> The MSTP at Michigan prepares physician scientists for careers in academic medicine with a focus on biomedical research. More than just an M.D. and Ph.D. spliced together, our program offers comprehensive support and guidance, integrating academic excellence and flexibility to help you reach your career goals.

<iframe width="560" height="315" src="https://www.youtube.com/embed/WkJBo7UzMNk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
