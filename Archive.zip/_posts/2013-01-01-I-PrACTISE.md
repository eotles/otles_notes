---
title: "I-PrACTISE"
categories:
  - Blog
tags:
  - medicine
  - healthcare
  - primary care
  - industrial engineering
  - human factors engineering
---


Helped to create I-PrACTISE. [I-PrACTISE](https://www.fammed.wisc.edu/i-practise/about/) is an educational and research collaborative between the University of Wisconsin Department of Industrial and Systems Engineering, and the Departments of Family Medicine and Community Health, Medicine and Pediatrics of the UW School of Medicine and Public Health.
