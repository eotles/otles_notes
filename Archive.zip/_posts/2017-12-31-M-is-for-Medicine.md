---
title: "M is for Medicine"
categories:
  - Blog
  - Project
tags:
  - iOS
  - mobile development
  - software development
  - Apple
---


I developed an an iMessage Sticker Pack for all those interested in medicine, health, and the human body. [Download it from the Apple AppSore](https://itunes.apple.com/us/app/m-is-for-medicine/id1229953773).
